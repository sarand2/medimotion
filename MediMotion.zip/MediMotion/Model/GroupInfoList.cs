﻿using System.Collections.Generic;

namespace MediMotion.Model
{
    public class GroupInfoList : List<object>
    {
        public object Key { get; set; }
    }
}
